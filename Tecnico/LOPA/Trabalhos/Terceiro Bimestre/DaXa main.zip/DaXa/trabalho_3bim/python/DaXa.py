import pygame as gam
from tkinter import messagebox
import chess as ch
import time as T
import json as J


gam.init()
TELA = gam.display.set_mode([680,540])
gam.display.set_caption("DaXa")
gam.display.set_icon(gam.transform.scale(gam.image.load("trabalho_3bim/imagens/icone.png").convert_alpha(), (769*0.019506,769*0.019506)))
telas_de_fundo = []
telas_de_fundo.append(gam.transform.scale(gam.image.load("trabalho_3bim/imagens/fundo_Tela.png").convert_alpha(), (242*2.81,237*2.81)))

class Opçao(gam.sprite.Sprite):
    def __init__(self, t):
        gam.sprite.Sprite.__init__(self)
        self.tipo = t
        self.quadros = []

        self.quadros.append(gam.transform.scale(gam.image.load("trabalho_3bim/imagens/xadrex.png"),(180*0.8, 134*0.8)))
        self.quadros.append(gam.transform.scale(gam.image.load("trabalho_3bim/imagens/damas.png"), (190*0.8, 125*0.8)))
        self.quadros.append(gam.transform.scale(gam.image.load("trabalho_3bim/imagens/botão historico.png"), (139*0.8, 135*0.8)))
        self.quadros.append(gam.transform.scale(gam.image.load("trabalho_3bim/imagens/X.png"),(55*0.6,45*0.6)))
        self.quadros.append(gam.transform.scale(gam.image.load("trabalho_3bim/imagens/X2.png"),(55*0.6,45*0.6)))
        
        if self.tipo == 1:
            self.image = self.quadros[0]
            
        elif self.tipo == 2:
            self.image = self.quadros[1]

        elif self.tipo == 3:
            self.image = self.quadros[2]

        elif self.tipo == 4:
            self.image = self.quadros[3]
            

        self.rect = self.image.get_rect()
        if self.tipo == 1:
            self.rect.topleft=375,135
        elif self.tipo == 2:
            self.rect.topleft=145,135
        elif self.tipo == 3:
            self.rect.topleft=-100,-100
        elif self.tipo == 4:
            self.rect.topleft=20,20

    def A(self,a):
        if a:
            self.image = self.quadros[4]
        else:
            self.image = self.quadros[3]

    def move(self,x,y):
        self.rect.topleft=x,y

    def update(self):
        if self.tipo == 1:
            self.image = self.quadros[0]
           
        elif self.tipo == 2:
            self.image = self.quadros[1]

        elif self.tipo == 3:
            self.image = self.quadros[2]

class Tabuleiro():
    def __init__(self, tip):
        self.tip = tip
        self.selecionado = False
        self.possivel = False
        self.linha = self.coluna = 0
        self.quadrado = gam.rect.Rect(0,0,50, 50)

        linha_temp = (tip - 1) // 8
        coluna_temp = (tip - 1) % 8
        self.color = (0,0,0) if (linha_temp + coluna_temp) % 2 == 0 else (255,255,255)

        self.quadrado.topleft = 145 + (coluna_temp * 50), 90 + (linha_temp * 50)
        self.casa_chess = ch.square(coluna_temp, 7 - linha_temp)

        

    
    def auto_locate(self,tab):
        for num_linha, linha in enumerate(tab):
            for num_coluna, peca in enumerate(linha):
                if peca is self:  
                    self.linha,self.coluna = num_linha, num_coluna
        self.quadrado.topleft = 145 + (self.coluna * 50), 90 + (self.linha * 50)

    def select(self,tab,turno):
        if tab[self.linha][self.coluna] != "-":
            if turno == tab[self.linha][self.coluna].time:
                self.selecionado = True
                tab[self.linha][self.coluna].selecionado = True
                return True
        return False

    def final(self,tab,tur,cap_b,cap_p):
        for linha in tab:
            for peca in linha:
                if peca != "-":
                    if peca.selecionado:
                        return peca.mover(tur,tab,(self.linha,self.coluna),cap_b,cap_p)
        

    def aparecer(self):
        if self.selecionado:
            cor = (218,240,139)
        else:
            cor = self.color
        gam.draw.rect(TELA,cor,self.quadrado)
        if self.possivel:
            gam.draw.rect(TELA, (40, 180, 80), self.quadrado, 4)
            gam.draw.circle(TELA, (40, 180, 80), self.quadrado.center, 7)
            
board_chess = ch.Board()
casa_origem_ch = None
linha_origem = None
coluna_origem = None

def at_matriz_xad(board_chess, game_Xad, dicionario_pecas):
    for linha in range(8):
        for coluna in range(8):
            square = ch.square(coluna, 7 - linha)
            piece = board_chess.piece_at(square)
            
            if piece is None:
                game_Xad[linha][coluna] = "-"
            else:
                game_Xad[linha][coluna] = dicionario_pecas[piece.symbol()]

class Pessa():
    def __init__(self, t):
        self.time = "pretas" if t == 1 else "brancas"
        self.capturado = False
        self.linha = 0
        self.coluna = 0

        
    def auto_locate(self,tab):
        for num_linha, linha in enumerate(tab):
            for num_coluna, peca in enumerate(linha):
                if peca is self:  
                    self.linha,self.coluna = num_linha, num_coluna
        if not(self.capturado):
            self.rect.topleft = 148 + (self.coluna * 50), 93 + (self.linha * 50)
        else:
            self.rect.topleft= -50,-50

class Pessa_Dam(gam.sprite.Sprite, Pessa):
    def __init__(self,t):
        gam.sprite.Sprite.__init__(self)
        Pessa.__init__(self, t)
        self.tipo = 1
        self.selecionado = False
        self.casas_possiveis = []

        self.quadros = []
    
        self.quadros.append(gam.transform.scale(gam.image.load("trabalho_3bim/imagens/Pessa_P.png"), (88*0.48, 88*0.48)))
        self.quadros.append(gam.transform.scale(gam.image.load("trabalho_3bim/imagens/Pessa_B.png"), (88*0.48, 88*0.48)))
        self.quadros.append(gam.transform.scale(gam.image.load("trabalho_3bim/imagens/Dama_P.png"), (88*0.48, 88*0.48)))
        self.quadros.append(gam.transform.scale(gam.image.load("trabalho_3bim/imagens/Dama_B.png"), (88*0.48, 88*0.48)))

        if self.time == "pretas":
            self.image = self.quadros[0]
        else:
            self.image = self.quadros[1]


        self.rect = self.image.get_rect()
        self.rect.topleft=145,90

    def go_playing(self,tab):
        if self.tipo == 1:
            checagem=[(2,2),(2,-2),(-2,2),(-2,-2)]

            for i in checagem:
                if -1 < self.linha + i[0] < 8  and -1 < self.coluna + i[1] < 8:
                    if tab[self.linha + i[0]][self.coluna + i[1]] == "-" and tab[self.linha + i[0]//2][self.coluna + i[1]//2] != "-":
                        if tab[self.linha + i[0]//2][self.coluna + i[1]//2].time != self.time:
                            return True
            return False

        else:
            diagonal = [True,True,True,True]
            for i in range(2,8):
                if diagonal[0]:
                    if -1 < self.linha + i < 8 and -1 < self.coluna + i < 8:
                        if tab[self.linha + i][self.coluna + i] == "-" and tab[self.linha + i-1][self.coluna + i-1] != "-":
                            if tab[self.linha + i-1][self.coluna + i-1].time != self.time:
                                return True
                            else:
                                diagonal[0] = False
                if diagonal[1]:
                    if -1 < self.linha + i < 8 and -1 < self.coluna - i < 8:
                        if tab[self.linha + i][self.coluna - i] == "-" and tab[self.linha + i-1][self.coluna - i+1] != "-":
                            if tab[self.linha + i-1][self.coluna - i+1].time != self.time:
                                return True
                            else:
                                diagonal[1] = False
                if diagonal[2]:
                    if -1 < self.linha - i < 8 and -1 < self.coluna + i < 8:
                        if tab[self.linha - i][self.coluna + i] == "-" and tab[self.linha - i+1][self.coluna + i-1] != "-":
                            if tab[self.linha - i+1][self.coluna + i-1].time != self.time:
                                return True
                            else:
                                diagonal[2] = False
                if diagonal[3]:
                    if -1 < self.linha - i < 8 and -1 < self.coluna - i < 8:
                        if tab[self.linha - i][self.coluna - i] == "-" and tab[self.linha - i+1][self.coluna - i+1] != "-":
                            if tab[self.linha - i+1][self.coluna - i+1].time != self.time:
                                return True
                            else:
                                diagonal[3] = False

            return False
            
        
    def mover(self,tur, tab, destino,cap_b,cap_p):
        if self.tipo == 1:
            dist_linha = destino[0] - self.linha
            dist_coluna = destino[1] - self.coluna
            
            sentido_permitido = -1 if self.time == "brancas" else 1
            
            if dist_linha == sentido_permitido and abs(dist_coluna) == 1:
                if tur[1] == 0:
                    if tab[destino[0]][destino[1]] == "-":
                        tab[self.linha][self.coluna] = "-"
                        tab[destino[0]][destino[1]] = self
                        if (self.time == "brancas" and destino[0] == 0) or (self.time == "pretas" and destino[0] == 7):
                            self.tipo = 2
                        self.linha = destino[0]
                        self.coluna = destino[1]
                        self.selecionado = False
                        return ["pretas", 0] if tur[0] == "brancas" else ["brancas", 0]

            elif abs(dist_linha) == 2 and abs(dist_coluna) == 2:
                linha_meio = self.linha + (dist_linha // 2)
                coluna_meio = self.coluna + (dist_coluna // 2)
                peca_meio = tab[linha_meio][coluna_meio]
                
                if tab[destino[0]][destino[1]] == "-" and peca_meio != "-":
                    if peca_meio.time != self.time:
                        peca_meio.capturado = True
                        if self.time == "brancas":
                            cap_p.append(peca_meio)
                        else:
                            cap_b.append(peca_meio)
                        tab[linha_meio][coluna_meio] = "-"
                        tab[self.linha][self.coluna] = "-"
                        tab[destino[0]][destino[1]] = self
                        self.linha = destino[0]
                        self.coluna = destino[1]
                        if (self.time == "brancas" and destino[0] == 0) or (self.time == "pretas" and destino[0] == 7):
                            self.tipo = 2
                            return ["pretas", 0] if tur[0] == "brancas" else ["brancas", 0]
                        if not(self.go_playing(tab)):
                            self.selecionado = False
                            return ["pretas", 0] if tur[0] == "brancas" else ["brancas", 0]
                        else:
                            return [tur[0], tur[1]+1]
                        
            self.selecionado = False
            return tur
        else:
            casas_com_pessa = []
            dist_linha = destino[0] - self.linha
            dist_coluna = destino[1] - self.coluna

            if abs(dist_linha) == abs(dist_coluna):
                for i in range(1,abs(dist_linha)):
                    if dist_linha > 0 and dist_coluna > 0:
                        if tab[destino[0] - i][destino[1] - i] != "-":
                            casas_com_pessa.append((destino[0] - i, destino[1] - i))
                    if dist_linha > 0 and dist_coluna < 0:
                        if tab[destino[0] - i][destino[1] + i] != "-":
                            casas_com_pessa.append((destino[0] - i, destino[1] + i))
                    if dist_linha < 0 and dist_coluna > 0:
                        if tab[destino[0] + i][destino[1] - i] != "-":
                            casas_com_pessa.append((destino[0] + i, destino[1] - i))
                    if dist_linha < 0 and dist_coluna < 0:
                        if tab[destino[0] + i][destino[1] + i] != "-":
                            casas_com_pessa.append((destino[0] + i, destino[1] + i))

                if tab[destino[0]][destino[1]] == "-":
                    if len(casas_com_pessa) == 0:
                        if tur[1] == 0:
                            tab[self.linha][self.coluna] = "-"
                            tab[destino[0]][destino[1]] = self
                            self.linha = destino[0]
                            self.coluna = destino[1]
                            self.selecionado = False
                            return ["pretas", 0] if tur[0] == "brancas" else ["brancas", 0]
                    
                    if len(casas_com_pessa) == 1:
                        if tab[casas_com_pessa[0][0]][casas_com_pessa[0][1]].time != self.time:
                            tab[casas_com_pessa[0][0]][casas_com_pessa[0][1]].capturado = True
                            if self.time == "brancas":
                                cap_p.append(tab[casas_com_pessa[0][0]][casas_com_pessa[0][1]])
                            else:
                                cap_b.append(tab[casas_com_pessa[0][0]][casas_com_pessa[0][1]])
                            tab[casas_com_pessa[0][0]][casas_com_pessa[0][1]] = "-"
                            tab[self.linha][self.coluna] = "-"
                            tab[destino[0]][destino[1]] = self
                            self.linha = destino[0]
                            self.coluna = destino[1]
                            if not(self.go_playing(tab)):
                                self.selecionado = False
                                return ["pretas", 0] if tur[0] == "brancas" else ["brancas", 0]
                            else:
                                return [tur[0], tur[1]+1]


            self.selecionado = False
            return tur

     
    def jgds_possiveis_dam(self, tab):
        self.casas_possiveis = []

        def valida(l, c):
            return 0 <= l < 8 and 0 <= c < 8

        if self.tipo == 1:
            sentido = -1 if self.time == "brancas" else 1

            for dc in [-1, 1]:
                nl, nc = self.linha + sentido, self.coluna + dc
                if valida(nl, nc) and tab[nl][nc] == "-":
                    self.casas_possiveis.append((nl, nc))

            for dl in [-1, 1]:
                for dc in [-1, 1]:
                    ml, mc = self.linha + dl, self.coluna + dc
                    fl, fc = self.linha + (dl * 2), self.coluna + (dc * 2)
                    if valida(fl, fc):
                        peca_meio = tab[ml][mc]
                        if peca_meio != "-" and peca_meio.time != self.time and tab[fl][fc] == "-":
                            self.casas_possiveis.append((fl, fc))

        else:
            direcoes = [(1, 1), (1, -1), (-1, 1), (-1, -1)]

            for dl, dc in direcoes:
                inimigo_no_caminho = False

                for dist in range(1, 8):
                    nl = self.linha + (dl * dist)
                    nc = self.coluna + (dc * dist)

                    if not valida(nl, nc):
                        break

                    peca_atual = tab[nl][nc]

                    if not inimigo_no_caminho:
                        if peca_atual == "-":
                            self.casas_possiveis.append((nl, nc))
                        elif peca_atual.time == self.time:
                            break
                        else:
                            inimigo_no_caminho = True
                    else:
                        if peca_atual == "-":
                            self.casas_possiveis.append((nl, nc))
                        break
        return self.casas_possiveis
    
            
    def update(self):
        if self.time == "pretas" and self.tipo == 1:
            self.image = self.quadros[0]
        elif self.time == "brancas" and self.tipo == 1:
            self.image = self.quadros[1]
        elif self.time == "pretas" and self.tipo == 2:
            self.image = self.quadros[2]
        else:
            self.image = self.quadros[3]
        if self.capturado == True:
            self.rect.topleft=-50,-50

class Pessa_Xad(gam.sprite.Sprite, Pessa):
    def __init__(self,tim,tip):
        gam.sprite.Sprite.__init__(self)
        Pessa.__init__(self, tim)
        self.tipo = tip
        self.quadros = []
    
        self.quadros.append(gam.transform.scale(gam.image.load("trabalho_3bim/imagens/peão branco.png"), (130*0.16, 260*0.16)))
        self.quadros.append(gam.transform.scale(gam.image.load("trabalho_3bim/imagens/peão preto.png"), (130*0.16, 260*0.16)))
        self.quadros.append(gam.transform.scale(gam.image.load("trabalho_3bim/imagens/torre branca.png"), (130*0.16, 260*0.16)))
        self.quadros.append(gam.transform.scale(gam.image.load("trabalho_3bim/imagens/torre preta.png"), (130*0.16, 260*0.16)))
        self.quadros.append(gam.transform.scale(gam.image.load("trabalho_3bim/imagens/cavalo branco.png"), (130*0.16, 260*0.16)))
        self.quadros.append(gam.transform.scale(gam.image.load("trabalho_3bim/imagens/cavalo preto.png"), (130*0.16, 260*0.16)))
        self.quadros.append(gam.transform.scale(gam.image.load("trabalho_3bim/imagens/bispo branco.png"), (130*0.16, 260*0.16)))
        self.quadros.append(gam.transform.scale(gam.image.load("trabalho_3bim/imagens/bispo preto.png"), (130*0.16, 260*0.16)))
        self.quadros.append(gam.transform.scale(gam.image.load("trabalho_3bim/imagens/rainha branca.png"), (130*0.16, 260*0.16)))
        self.quadros.append(gam.transform.scale(gam.image.load("trabalho_3bim/imagens/rainha preta.png"), (130*0.16, 260*0.16)))
        self.quadros.append(gam.transform.scale(gam.image.load("trabalho_3bim/imagens/rei branco.png"), (130*0.16, 260*0.16)))
        self.quadros.append(gam.transform.scale(gam.image.load("trabalho_3bim/imagens/rei preto.png"), (130*0.16, 260*0.16)))
        

        if self.time == "brancas" and tip == "pião":
            self.image = self.quadros[0]
        elif self.time == "pretas" and tip == "pião":
            self.image = self.quadros[1]
        elif self.time == "brancas" and tip == "torre":
            self.image = self.quadros[2]
        elif self.time == "pretas" and tip == "torre":
            self.image = self.quadros[3]
        elif self.time == "brancas" and tip == "cavalo":
            self.image = self.quadros[4]
        elif self.time == "pretas" and tip == "cavalo":
            self.image = self.quadros[5]
        elif self.time == "brancas" and tip == "bispo":
            self.image = self.quadros[6]
        elif self.time == "pretas" and tip == "bispo":
            self.image = self.quadros[7]
        elif self.time == "brancas" and tip == "rainha":
            self.image = self.quadros[8]
        elif self.time == "pretas" and tip == "rainha":
            self.image = self.quadros[9]
        elif self.time == "brancas" and tip == "rei":
            self.image = self.quadros[10]
        elif self.time == "pretas" and tip == "rei":
            self.image = self.quadros[11]
        
        self.rect = self.image.get_rect()
        self.rect.topleft=145,90

    def auto_locate(self,tab):
            for num_linha, linha in enumerate(tab):
                for num_coluna, peca in enumerate(linha):
                    if peca is self:  
                        self.linha,self.coluna = num_linha, num_coluna
            if not(self.capturado):
                self.rect.topleft = 160 + (self.coluna * 50), 95 + (self.linha * 50)
            else:
                self.rect.topleft= -50,-50

    def update(self):
        if self.capturado:
            self.rect.topleft = -100, -100
            return
        if self.time == "brancas" and self.tipo == "pião":
            self.image = self.quadros[0]
  
            
        if self.time == "brancas" and self.tipo == "pião":
            self.image = self.quadros[0]
        elif self.time == "pretas" and self.tipo == "pião":
            self.image = self.quadros[1]
        elif self.time == "brancas" and self.tipo == "torre":
            self.image = self.quadros[2]
        elif self.time == "pretas" and self.tipo == "torre":
            self.image = self.quadros[3]
        elif self.time == "brancas" and self.tipo == "cavalo":
            self.image = self.quadros[4]
        elif self.time == "pretas" and self.tipo == "cavalo":
            self.image = self.quadros[5]
        elif self.time == "brancas" and self.tipo == "bispo":
            self.image = self.quadros[6]
        elif self.time == "pretas" and self.tipo == "bispo":
            self.image = self.quadros[7]
        elif self.time == "brancas" and self.tipo == "rainha":
            self.image = self.quadros[8]
        elif self.time == "pretas" and self.tipo == "rainha":
            self.image = self.quadros[9]
        elif self.time == "brancas" and self.tipo == "rei":
            self.image = self.quadros[10]
        elif self.time == "pretas" and self.tipo == "rei":
            self.image = self.quadros[11]
        
xadres_b = Opçao(1)
damas_b = Opçao(2)
historico_b = Opçao(3)
historico_b.move(275,300)

all_quadros1 = gam.sprite.Group()
all_quadros1.add(xadres_b)
all_quadros1.add(damas_b)
all_quadros1.add(historico_b)

# declaração dos botões do tabuleiro e o if é só pra poder esconder
if True:
    A1 = Tabuleiro(1)
    B1 = Tabuleiro(2)
    C1 = Tabuleiro(3)
    D1 = Tabuleiro(4)
    E1 = Tabuleiro(5)
    F1 = Tabuleiro(6)
    G1 = Tabuleiro(7)
    H1 = Tabuleiro(8)
    A2 = Tabuleiro(9)
    B2 = Tabuleiro(10)
    C2 = Tabuleiro(11)
    D2 = Tabuleiro(12)
    E2 = Tabuleiro(13)
    F2 = Tabuleiro(14)
    G2 = Tabuleiro(15)
    H2 = Tabuleiro(16)
    A3 = Tabuleiro(17)
    B3 = Tabuleiro(18)
    C3 = Tabuleiro(19)
    D3 = Tabuleiro(20)
    E3 = Tabuleiro(21)
    F3 = Tabuleiro(22)
    G3 = Tabuleiro(23)
    H3 = Tabuleiro(24)
    A4 = Tabuleiro(25)
    B4 = Tabuleiro(26)
    C4 = Tabuleiro(27)
    D4 = Tabuleiro(28)
    E4 = Tabuleiro(29)
    F4 = Tabuleiro(30)
    G4 = Tabuleiro(31)
    H4 = Tabuleiro(32)
    A5 = Tabuleiro(33)
    B5 = Tabuleiro(34)
    C5 = Tabuleiro(35)
    D5 = Tabuleiro(36)
    E5 = Tabuleiro(37)
    F5 = Tabuleiro(38)
    G5 = Tabuleiro(39)
    H5 = Tabuleiro(40)
    A6 = Tabuleiro(41)
    B6 = Tabuleiro(42)
    C6 = Tabuleiro(43)
    D6 = Tabuleiro(44)
    E6 = Tabuleiro(45)
    F6 = Tabuleiro(46)
    G6 = Tabuleiro(47)
    H6 = Tabuleiro(48)
    A7 = Tabuleiro(49)
    B7 = Tabuleiro(50)
    C7 = Tabuleiro(51)
    D7 = Tabuleiro(52)
    E7 = Tabuleiro(53)
    F7 = Tabuleiro(54)
    G7 = Tabuleiro(55)
    H7 = Tabuleiro(56)
    A8 = Tabuleiro(57)
    B8 = Tabuleiro(58)
    C8 = Tabuleiro(59)
    D8 = Tabuleiro(60)
    E8 = Tabuleiro(61)
    F8 = Tabuleiro(62)
    G8 = Tabuleiro(63)
    H8 = Tabuleiro(64)

tabuleiro = [
    [A1, B1, C1, D1,E1,F1,G1,H1],
    [A2, B2, C2, D2,E2,F2,G2,H2],
    [A3, B3, C3, D3,E3,F3,G3,H3],
    [A4, B4, C4, D4,E4,F4,G4,H4],
    [A5, B5, C5, D5,E5,F5,G5,H5],
    [A6, B6, C6, D6,E6,F6,G6,H6],
    [A7, B7, C7, D7,E7,F7,G7,H7],
    [A8, B8, C8, D8,E8,F8,G8,H8]
]
for i in tabuleiro:
    for j in i:
        j.auto_locate(tabuleiro)

# declaração das peças do tabuleiro e o if é só pra poder esconder
if True:
    pessa_B1 = Pessa_Dam(2)
    pessa_P1 = Pessa_Dam(1)
    pessa_B2 = Pessa_Dam(2)
    pessa_P2 = Pessa_Dam(1)
    pessa_B3 = Pessa_Dam(2)
    pessa_P3 = Pessa_Dam(1)
    pessa_B4 = Pessa_Dam(2)
    pessa_P4 = Pessa_Dam(1)
    pessa_B5 = Pessa_Dam(2)
    pessa_P5 = Pessa_Dam(1)
    pessa_B6 = Pessa_Dam(2)
    pessa_P6 = Pessa_Dam(1)
    pessa_B7 = Pessa_Dam(2)
    pessa_P7 = Pessa_Dam(1)
    pessa_B8 = Pessa_Dam(2)
    pessa_P8 = Pessa_Dam(1)
    pessa_B9 = Pessa_Dam(2)
    pessa_P9 = Pessa_Dam(1)
    pessa_B10 = Pessa_Dam(2)
    pessa_P10 = Pessa_Dam(1)
    pessa_B11 = Pessa_Dam(2)
    pessa_P11 = Pessa_Dam(1)
    pessa_B12 = Pessa_Dam(2)
    pessa_P12 = Pessa_Dam(1)

game_dam = [
    [pessa_P1,"-",pessa_P2,"-",pessa_P3,"-",pessa_P4,"-"],
    ["-",pessa_P5,"-",pessa_P6,"-",pessa_P7,"-",pessa_P8],
    [pessa_P9,"-",pessa_P10,"-",pessa_P11,"-",pessa_P12,"-"],
    ["-","-","-","-","-","-","-","-"],
    ["-","-","-","-","-","-","-","-"],
    ["-",pessa_B9,"-",pessa_B10,"-",pessa_B11,"-",pessa_B12],
    [pessa_B5,"-",pessa_B6,"-",pessa_B7,"-",pessa_B8,"-"],
    ["-",pessa_B1,"-",pessa_B2,"-",pessa_B3,"-",pessa_B4]
]

all_quadros2 = gam.sprite.Group()
for i in game_dam:
    for j in i:
        if j != "-":
            all_quadros2.add(j)


if True:
    piao_1p = Pessa_Xad(1, "pião")
    piao_1b = Pessa_Xad(2, "pião")
    piao_2p = Pessa_Xad(1, "pião")
    piao_2b = Pessa_Xad(2, "pião")
    piao_3p = Pessa_Xad(1, "pião")
    piao_3b = Pessa_Xad(2, "pião")
    piao_4p = Pessa_Xad(1, "pião")
    piao_4b = Pessa_Xad(2, "pião")
    piao_5p = Pessa_Xad(1, "pião")
    piao_5b = Pessa_Xad(2, "pião")
    piao_6p = Pessa_Xad(1, "pião")
    piao_6b = Pessa_Xad(2, "pião")
    piao_7p = Pessa_Xad(1, "pião")
    piao_7b = Pessa_Xad(2, "pião")
    piao_8p = Pessa_Xad(1, "pião")
    piao_8b = Pessa_Xad(2, "pião")
    torre_1p = Pessa_Xad(1, "torre")
    torre_1b = Pessa_Xad(2, "torre")
    torre_2p = Pessa_Xad(1, "torre")
    torre_2b = Pessa_Xad(2, "torre")
    cavalo_1p = Pessa_Xad(1, "cavalo")
    cavalo_1b = Pessa_Xad(2, "cavalo")
    cavalo_2p = Pessa_Xad(1, "cavalo")
    cavalo_2b = Pessa_Xad(2, "cavalo")
    bispo_1p = Pessa_Xad(1, "bispo")
    bispo_1b = Pessa_Xad(2, "bispo") 
    bispo_2p = Pessa_Xad(1, "bispo")
    bispo_2b = Pessa_Xad(2, "bispo")
    rainha_p = Pessa_Xad(1, "rainha")
    rainha_b = Pessa_Xad(2, "rainha")
    rei_p = Pessa_Xad(1, "rei")
    rei_b = Pessa_Xad(2, "rei")

game_Xad = [
    [torre_1p, cavalo_1p, bispo_1p, rainha_p, rei_p, bispo_2p, cavalo_2p, torre_2p],
    [piao_1p ,piao_2p , piao_3p, piao_4p, piao_5p, piao_6p ,piao_7p, piao_8p],
    ["-","-","-","-","-","-","-","-",],
    ["-","-","-","-","-","-","-","-",],
    ["-","-","-","-","-","-","-","-",],
    ["-","-","-","-","-","-","-","-",],
    [piao_1b, piao_2b, piao_3b, piao_4b, piao_5b, piao_6b, piao_7b, piao_8b],
    [torre_1b, cavalo_1b, bispo_1b, rainha_b, rei_b, bispo_2b, cavalo_2b, torre_2b]
]
all_quadros3 = gam.sprite.Group()
for i in game_Xad:
    for j in i:
        if j != "-":
            all_quadros3.add(j)

font = gam.font.SysFont(None, 35)

jogando_xa = False
jogando_da = False
saida = False
contra_ia = True
contra_ia_dam = True

historico1_b = Opçao(3)
historico1_b.move(110,100)
historico2_b = Opçao(3)
historico3_b = Opçao(3)
historico4_b = Opçao(3)
historico5_b = Opçao(3)
fechar_b = Opçao(4)
all_quadros4 = gam.sprite.Group()
all_quadros4.add(historico1_b)
all_quadros4.add(historico2_b)
all_quadros4.add(historico3_b)
all_quadros4.add(historico4_b)
all_quadros4.add(historico5_b)
all_quadros4.add(fechar_b)

pessa_selecionada = False

clock = gam.time.Clock()

inicio_turno = T.perf_counter()

try:
    with open("historico_jogos.json", "r") as arquivo:
        relat = J.load(arquivo)
except FileNotFoundError:
    relat = {
        "atual_dam": {
            "turno": ["brancas", 0],
            "pecas_capt_B": [],
            "pecas_capt_P": [],
            "tabuleiro": [],
            "tempo_b": 0.0,
            "tempo_p": 0.0
        },
        "atual_xad": {},
        "ultimo1": {},
        "ultimo2": {},
        "ultimo3": {},
        "ultimo4": {},
        "ultimo5": {}
    }

v_historico = False
historico1 = False
historico2 = False
historico3 = False
historico4 = False
historico5 = False
pecas_capt_B = []
pecas_capt_P = []

relat["atual_xad"] = {"tempo_b": 0.0, "tempo_p": 0.0}
inicio_turno_xad = T.perf_counter()

def resetar_xadrez():
    global casa_origem_ch, inicio_turno_xad
    board_chess.reset()
    casa_origem_ch = None
    
    relat["atual_xad"] = {
        "tempo_b": 0.0,
        "tempo_p": 0.0
    }
    inicio_turno_xad = T.perf_counter()

    game_Xad[:] = [
        [torre_1p, cavalo_1p, bispo_1p, rainha_p, rei_p, bispo_2p, cavalo_2p, torre_2p],
        [piao_1p,  piao_2p,  piao_3p,  piao_4p,  piao_5p,  piao_6p,  piao_7p,  piao_8p],
        ["-"] * 8, ["-"] * 8, ["-"] * 8, ["-"] * 8,
        [piao_1b,  piao_2b,  piao_3b,  piao_4b,  piao_5b,  piao_6b,  piao_7b,  piao_8b],
        [torre_1b, cavalo_1b, bispo_1b, rainha_b, rei_b, bispo_2b, cavalo_2b, torre_2b]
    ]

    for peca in all_quadros3:
        peca.capturado = False
        peca.selecionado = False
        if peca in game_Xad[1] or peca in game_Xad[6]:
            peca.tipo = "pião"
        peca.auto_locate(game_Xad)

    for linha in tabuleiro:
        for casa in linha:
            casa.selecionado = False
            casa.possivel = False


def resetar_damas():
    global turno, pessa_selecionada, inicio_turno
    
    relat["atual_dam"] = {
        "turno": ["brancas", 0],
        "pecas_capt_B": [],
        "pecas_capt_P": [],
        "tabuleiro": [],
        "tempo_b": 0.0,
        "tempo_p": 0.0
    }
    
    turno = "brancas"
    pessa_selecionada = False
    inicio_turno = T.perf_counter()

    game_dam[:] = [
        [pessa_P1, "-", pessa_P2, "-", pessa_P3, "-", pessa_P4, "-"],
        ["-", pessa_P5, "-", pessa_P6, "-", pessa_P7, "-", pessa_P8],
        [pessa_P9, "-", pessa_P10, "-", pessa_P11, "-", pessa_P12, "-"],
        ["-"] * 8, ["-"] * 8,
        ["-", pessa_B9, "-", pessa_B10, "-", pessa_B11, "-", pessa_B12],
        [pessa_B5, "-", pessa_B6, "-", pessa_B7, "-", pessa_B8, "-"],
        ["-", pessa_B1, "-", pessa_B2, "-", pessa_B3, "-", pessa_B4]
    ]

    for peca in all_quadros2:
        peca.capturado = False
        peca.selecionado = False
        peca.tipo = 1
        peca.auto_locate(game_dam)

    for linha in tabuleiro:
        for casa in linha:
            casa.selecionado = False
            casa.possivel = False
            
      
class tabuleiro_ch(ch.Board):
    def __init__(self):
        super().__init__()
        self.turn = ch.WHITE
        self.legal_moves = []
        for i in range(8):
            for j in range(8):
                self.board[i * 8 + j] = ch.peca(i, j)
                if self.board[i * 8 + j].color == self.turn:
                    self.legal_moves.append(ch.Move(self.board[i * 8 + j], self.board[i * 8 + j]))
                    self.legal_moves.append(ch.Move(self.board[i * 8 + j], self.board[i * 8 + j]))
                else:
                    self.legal_moves.append(ch.Move(self.board[i * 8 + j], self.board[i * 8 + j]))
                    
    def update(self):
        if self.capturado:
            self.rect.topleft = -1000, -1000
            
board_chess = ch.Board()
casa_origem_ch = None
linha_origem = None
coluna_origem = None

def sincronizar_xadrez(movimento):
    linha_origem = 7 - ch.square_rank(movimento.from_square)
    coluna_origem = ch.square_file(movimento.from_square)

    linha_destino = 7 - ch.square_rank(movimento.to_square)
    coluna_destino = ch.square_file(movimento.to_square)

    peca = game_Xad[linha_origem][coluna_origem]
    capturada = game_Xad[linha_destino][coluna_destino]

    if capturada != "-":
        capturada.capturado = True

    game_Xad[linha_origem][coluna_origem] = "-"
    game_Xad[linha_destino][coluna_destino] = peca

    if movimento.promotion == ch.QUEEN:
        peca.tipo = "rainha"
        
def at_matriz_xad(board_chess, game_Xad, dicionario_pecas):
    for linha in range(8):
        for coluna in range(8):
            square = ch.square(coluna, 7 - linha)
            piece = board_chess.piece_at(square)
            
            if piece is None:
                game_Xad[linha][coluna] = "-"
            else:
                game_Xad[linha][coluna] = dicionario_pecas[piece.symbol()]
VALORES_XADREZ = {
    ch.PAWN: 1,
    ch.KNIGHT: 3,
    ch.BISHOP: 3,
    ch.ROOK: 5,
    ch.QUEEN: 9,
    ch.KING: 100
}


def avaliar_tabuleiro(board):
    valor = 0

    for peca in board.piece_map().values():
        pontos = VALORES_XADREZ[peca.piece_type]

        if peca.color == ch.WHITE:
            valor += pontos
        else:
            valor -= pontos

    return valor


def minimax(board, profundidade, maximizando):
    if profundidade == 0 or board.is_game_over():
        return avaliar_tabuleiro(board), None
# to com fome
    melhor_movimento = None

    if maximizando:
        melhor_valor = float("-inf")

        for movimento in board.legal_moves:
            board.push(movimento)
            valor, _ = minimax(board, profundidade - 1, False)
            board.pop()

            if valor > melhor_valor:
                melhor_valor = valor
                melhor_movimento = movimento

        return melhor_valor, melhor_movimento

    pior_valor = float("inf")

    for movimento in board.legal_moves:
        board.push(movimento)
        valor, _ = minimax(board, profundidade - 1, True)
        board.pop()

        if valor < pior_valor:
            pior_valor = valor
            melhor_movimento = movimento

    return pior_valor, melhor_movimento


def estado_damas(tab):
    return tuple(
        tuple("-" if peca == "-" else (peca.time, peca.tipo) for peca in linha)
        for linha in tab
    )


def movimentos_damas(estado, jogador):
    movimentos = []
    direcoes = [(1, 1), (1, -1), (-1, 1), (-1, -1)]

    for linha in range(8):
        for coluna in range(8):
            peca = estado[linha][coluna]
            if peca == "-" or peca[0] != jogador:
                continue

            if peca[1] == 1:
                sentido = -1 if jogador == "brancas" else 1
                for dc in [-1, 1]:
                    destino = (linha + sentido, coluna + dc)
                    if 0 <= destino[0] < 8 and 0 <= destino[1] < 8 and estado[destino[0]][destino[1]] == "-":
                        movimentos.append(((linha, coluna), destino))

                for dl, dc in direcoes:
                    meio = (linha + dl, coluna + dc)
                    destino = (linha + 2 * dl, coluna + 2 * dc)
                    if 0 <= destino[0] < 8 and 0 <= destino[1] < 8 and 0 <= meio[0] < 8 and 0 <= meio[1] < 8:
                        if estado[meio[0]][meio[1]] != "-" and estado[meio[0]][meio[1]][0] != jogador and estado[destino[0]][destino[1]] == "-":
                            movimentos.append(((linha, coluna), destino))
            else:
                for dl, dc in direcoes:
                    for distancia in range(1, 8):
                        destino = (linha + dl * distancia, coluna + dc * distancia)
                        if not (0 <= destino[0] < 8 and 0 <= destino[1] < 8):
                            break
                        if estado[destino[0]][destino[1]] == "-":
                            movimentos.append(((linha, coluna), destino))
                        else:
                            if estado[destino[0]][destino[1]][0] != jogador:
                                depois = distancia + 1
                                while 0 <= linha + dl * depois < 8 and 0 <= coluna + dc * depois < 8 and estado[linha + dl * depois][coluna + dc * depois] == "-":
                                    movimentos.append(((linha, coluna), (linha + dl * depois, coluna + dc * depois)))
                                    depois += 1
                            break
    return movimentos


def aplicar_movimento_damas(estado, movimento):
    origem, destino = movimento
    tab = [list(linha) for linha in estado]
    peca = tab[origem[0]][origem[1]]
    tab[origem[0]][origem[1]] = "-"

    dl = 1 if destino[0] > origem[0] else -1
    dc = 1 if destino[1] > origem[1] else -1
    linha, coluna = origem[0] + dl, origem[1] + dc
    while (linha, coluna) != destino:
        if tab[linha][coluna] != "-":
            tab[linha][coluna] = "-"
            break
        linha += dl
        coluna += dc

    if peca[1] == 1 and ((peca[0] == "brancas" and destino[0] == 0) or (peca[0] == "pretas" and destino[0] == 7)):
        peca = (peca[0], 2)
    tab[destino[0]][destino[1]] = peca
    return tuple(tuple(linha) for linha in tab)


def avaliar_damas(estado):
    valor = 0
    for linha in estado:
        for peca in linha:
            if peca != "-":
                pontos = 5 if peca[1] == 2 else 1
                valor += pontos if peca[0] == "pretas" else -pontos
    return valor


def minimax_damas(estado, profundidade, jogador):
    movimentos = movimentos_damas(estado, jogador)
    if profundidade == 0 or not movimentos:
        return avaliar_damas(estado), None

    maximizando = jogador == "pretas"
    melhor_valor = float("-inf") if maximizando else float("inf")
    melhor_movimento = None

    for movimento in movimentos:
        novo_estado = aplicar_movimento_damas(estado, movimento)
        proximo_jogador = "brancas" if jogador == "pretas" else "pretas"
        valor, _ = minimax_damas(novo_estado, profundidade - 1, proximo_jogador)
        if (maximizando and valor > melhor_valor) or (not maximizando and valor < melhor_valor):
            melhor_valor = valor
            melhor_movimento = movimento

    return melhor_valor, melhor_movimento

while not(saida):

    dt = clock.tick(30)

    pos_mouse = gam.mouse.get_pos()
    for evento in gam.event.get():
        if evento.type == gam.QUIT or saida:
            saida=True
            break

        elif evento.type == gam.MOUSEBUTTONDOWN:
            if evento.button == 1 and xadres_b.rect.collidepoint(pos_mouse):
                resetar_xadrez()
                jogando_xa = True
                turno_B = True
                TELA = gam.display.set_mode([680,580])
            elif evento.button == 1 and damas_b.rect.collidepoint(pos_mouse):
                resetar_damas()
                jogando_da = True
                turno_B = True
                inicio_turno = T.perf_counter()
                TELA = gam.display.set_mode([680,580])
            elif evento.button == 1 and historico_b.rect.collidepoint(pos_mouse):
                if relat["ultimo1"]!={}:
                    v_historico = True
                else:
                    messagebox.showinfo("Erro", "Ainda não há histórico")


    
 
    TELA.fill((0, 0, 0))
    TELA.blit(telas_de_fundo[0],(0,-75))

    if not(damas_b.rect.collidepoint(pos_mouse)):
        gam.draw.rect(TELA,(0,0,0),(143,133,156, 104))
        text_d = font.render('Play Damas', True, (0,0,0))
    else:
        gam.draw.rect(TELA,(0,110,0),(143,133,156, 104))
        text_d = font.render('Play Damas', True, (0,110,0))
    if not(xadres_b.rect.collidepoint(pos_mouse)):
        gam.draw.rect(TELA,(0,0,0),(373,133,148, 111))
        text_x = font.render('Play Xadrez', True, (0,0,0))
    else:
        gam.draw.rect(TELA,(0,110,0),(373,133,148, 111))
        text_x = font.render('Play Xadrez', True, (0,110,0))
    if not(historico_b.rect.collidepoint(pos_mouse)):
        gam.draw.rect(TELA,(0,0,0),historico_b.rect.inflate(4, 4))
        text_h = font.render('Histórico', True, (0,0,0))
    else:
        gam.draw.rect(TELA,(0,110,0),historico_b.rect.inflate(4, 4))
        text_h = font.render('Histórico', True, (0,110,0))

    TELA.blit(text_d, [155,95])
    TELA.blit(text_x, [380,98])
    TELA.blit(text_h, [287,265])
    all_quadros1.draw(TELA)
    gam.display.flip()

    while not(saida) and jogando_da and len(relat["atual_dam"]["pecas_capt_B"])<12 and len(relat["atual_dam"]["pecas_capt_P"])<12:
            dt = clock.tick(30)
            
            pos_mouse = gam.mouse.get_pos()
        
            for evento in gam.event.get():
                if evento.type == gam.QUIT or saida:
                    saida=True
                    break
                elif evento.type == gam.KEYDOWN and evento.key == gam.K_ESCAPE:
                    jogando_da = False
                    TELA = gam.display.set_mode([680, 540])
                    break
                elif evento.type == gam.KEYDOWN and evento.key == gam.K_i:
                    contra_ia_dam = not contra_ia_dam
                if evento.type == gam.MOUSEBUTTONDOWN:
                    if evento.button == 1:
                        for i in tabuleiro:
                            for j in i:
                                if j.quadrado.collidepoint(pos_mouse):
                                    if not(pessa_selecionada) and relat["atual_dam"]["turno"][1] == 0:
                                        pessa_selecionada = j.select(game_dam, relat["atual_dam"]["turno"][0])
                                        if pessa_selecionada:
                                            for linha_p in game_dam:
                                                for peca_p in linha_p:
                                                    if peca_p != "-" and peca_p.selecionado:
                                                        for linha, coluna in peca_p.jgds_possiveis_dam(game_dam):
                                                            tabuleiro[linha][coluna].possivel = True
                                        
                                    elif pessa_selecionada:
                                        turno_anterior = relat["atual_dam"]["turno"].copy()
                                        
                                        relat["atual_dam"]["turno"] = j.final(game_dam, relat["atual_dam"]["turno"], relat["atual_dam"]["pecas_capt_B"], relat["atual_dam"]["pecas_capt_P"])
                                        
                                        if relat["atual_dam"]["turno"] == turno_anterior and relat["atual_dam"]["turno"][1] == 0:
                                            pessa_selecionada = False
                                            for linha_t in tabuleiro:
                                                for casa_t in linha_t:
                                                    casa_t.selecionado = False
                                            for linha_t in tabuleiro:
                                                for casa_t in linha_t:
                                                    casa_t.possivel = False
                                            for linha_p in game_dam:
                                                for peca_p in linha_p:
                                                    if peca_p != "-": peca_p.selecionado = False
                                            continue

                                        elif relat["atual_dam"]["turno"] == turno_anterior and relat["atual_dam"]["turno"][1] > 0:
                                            relat["atual_dam"]["turno"] = ["pretas", 0] if turno_anterior[0] == "brancas" else ["brancas", 0]
                                            pessa_selecionada = False
                                            for linha_t in tabuleiro:
                                                for casa_t in linha_t:
                                                    casa_t.selecionado = False
                                                    casa_t.possivel = False
                                            for linha_p in game_dam:
                                                for peca_p in linha_p:
                                                    if peca_p != "-": peca_p.selecionado = False
                                            continue
        
                                        if relat["atual_dam"]["turno"][1] == 0:
                                            pessa_selecionada = False
                                            for linha_t in tabuleiro:
                                                for casa_t in linha_t:
                                                    casa_t.selecionado = False
                                                    casa_t.possivel = False
                                            for linha_p in game_dam:
                                                for peca_p in linha_p:
                                                    if peca_p != "-":
                                                        peca_p.selecionado = False
                                                        
                                        
                                        else:
                                            pessa_selecionada = True
                                            
                                            for linha_t in tabuleiro:
                                                for casa_t in linha_t:
                                                    casa_t.selecionado = False
                                                    
                                            
                                            for linha_p in game_dam:
                                                for peca_p in linha_p:
                                                    if peca_p != "-" and peca_p.selecionado:
                                                        tabuleiro[peca_p.linha][peca_p.coluna].selecionado = True

            if contra_ia_dam and relat["atual_dam"]["turno"][0] == "pretas":
                estado = estado_damas(game_dam)
                _, movimento_ia = minimax_damas(estado, 2, "pretas")

                if movimento_ia is not None:
                    origem, destino = movimento_ia
                    peca_ia = game_dam[origem[0]][origem[1]]
                    peca_ia.auto_locate(game_dam)
                    peca_ia.selecionado = True
                    relat["atual_dam"]["turno"] = peca_ia.mover(
                        relat["atual_dam"]["turno"],
                        game_dam,
                        destino,
                        relat["atual_dam"]["pecas_capt_B"],
                        relat["atual_dam"]["pecas_capt_P"]
                    )
                    pessa_selecionada = False


            agora = T.perf_counter()
            tempo_decorrido = agora - inicio_turno
            inicio_turno = agora          

            if relat["atual_dam"]["turno"][0] == "brancas":
                relat["atual_dam"]["tempo_b"] += tempo_decorrido
            else:
                relat["atual_dam"]["tempo_p"] += tempo_decorrido
            
            for i in game_dam:
                for j in i:
                    if j != "-":
                        j.auto_locate(game_dam)
            
            TELA.fill((255, 197, 0))
            for i in tabuleiro:
                for j in i:
                    j.aparecer()

            txt_tempo_b, txt_tempo_p = font.render(f"B: {int(relat['atual_dam']['tempo_b'])//60}:{int(relat['atual_dam']['tempo_b'])%60:02d}", True, (0,0,0)), font.render(f"P: {int(relat['atual_dam']['tempo_p'])//60}:{int(relat['atual_dam']['tempo_p'])%60:02d}", True, (0,0,0))
            TELA.blit(txt_tempo_p, [305, 40])
            TELA.blit(txt_tempo_b, [305, 520])
            all_quadros2.update()
            all_quadros2.draw(TELA)
            TELA.blit(font.render("ESC: voltar ao menu", True, (0, 0, 0)), [5, 5])
            status_ia = "ligada" if contra_ia_dam else "desligada"
            TELA.blit(font.render(f"IA: {status_ia}", True, (0, 0, 0)), [5, 40])
            gam.display.flip()

            if len(relat["atual_dam"]["pecas_capt_P"])==12:
                TELA = gam.display.set_mode([680,540])
                jogando_da = False
                historico1 = True
                v_historico = True
                
                relat["ultimo5"] = relat["ultimo4"].copy()
                relat["ultimo4"] = relat["ultimo3"].copy()
                relat["ultimo3"] = relat["ultimo2"].copy()
                relat["ultimo2"] = relat["ultimo1"].copy()

                relat["ultimo1"]["game"] = "Jogo: Damas"
                relat["ultimo1"]["vencedor"] = "Vencedor: Brancas"
                relat["ultimo1"]["pecas_capt_B"] = f"Peças capturadas Brancas: {len(relat['atual_dam']['pecas_capt_B'])}"
                relat["ultimo1"]["pecas_capt_P"] = f"Peças capturadas Pretas: {len(relat['atual_dam']['pecas_capt_P'])}"
                relat["ultimo1"]["tempo"] = f"Tempo de jogo: {int(relat['atual_dam']['tempo_b'] + relat['atual_dam']['tempo_p'])//60}:{int(relat['atual_dam']['tempo_b'] + relat['atual_dam']['tempo_p'])%60:02d}"

                resetar_damas()

                with open("historico_jogos.json", "w") as arquivo:
                    J.dump(relat, arquivo, indent=4)

                
                
            elif len(relat["atual_dam"]["pecas_capt_B"])==12:
                TELA = gam.display.set_mode([680,540])
                jogando_da = False
                historico1 = True
                v_historico = True

                relat["ultimo5"] = relat["ultimo4"].copy()
                relat["ultimo4"] = relat["ultimo3"].copy()
                relat["ultimo3"] = relat["ultimo2"].copy()
                relat["ultimo2"] = relat["ultimo1"].copy()

                relat["ultimo1"]["game"] = "Jogo: Damas"
                relat["ultimo1"]["vencedor"] = "Vencedor: Pretas"
                relat["ultimo1"]["pecas_capt_B"] = f"Peças capturadas Brancas: {len(relat["atual_dam"]["pecas_capt_B"])}"
                relat["ultimo1"]["pecas_capt_P"] = f"Peças capturadas Pretas: {len(relat["atual_dam"]["pecas_capt_P"])}"
                relat["ultimo1"]["tempo"] = f"Tempo de jogo {int(relat["atual_dam"]["tempo_b"] + relat["atual_dam"]["tempo_p"])//60}:{int(relat["atual_dam"]["tempo_b"] + relat["atual_dam"]["tempo_p"])%60:02d}"

                resetar_damas()

                with open("historico_jogos.json", "w") as arquivo:
                    J.dump(relat, arquivo, indent=4)

                

    while not(saida) and jogando_xa:
        dt = clock.tick(30)

        agora = T.perf_counter()
        tempo_decorrido = agora - inicio_turno_xad
        inicio_turno_xad = agora

        if board_chess.turn == ch.WHITE:
            relat["atual_xad"]["tempo_b"] += tempo_decorrido
        else:
            relat["atual_xad"]["tempo_p"] += tempo_decorrido

        pos_mouse = gam.mouse.get_pos()
    
        for evento in gam.event.get():
            if evento.type == gam.QUIT or saida:
                saida=True
                break
            elif evento.type == gam.KEYDOWN and evento.key == gam.K_ESCAPE:
                jogando_xa = False
                TELA = gam.display.set_mode([680, 540])
                break
            elif evento.type == gam.KEYDOWN and evento.key == gam.K_i:
                contra_ia = not contra_ia

            elif evento.type == gam.MOUSEBUTTONDOWN:
                if board_chess.is_game_over():
                    continue
                
                if evento.button == 1:
                    for i in tabuleiro:
                         for j in i:
                             if j.quadrado.collidepoint(pos_mouse):
                                casa_atual_ch = j.casa_chess
                                linha_p = (j.tip - 1) // 8
                                coluna_p = (j.tip - 1) % 8

                                if casa_origem_ch is None:
                                    peca_clicada = game_Xad[linha_p][coluna_p]
                                    if peca_clicada != "-":
                                        turno_correto = (
                                            (peca_clicada.time == "brancas" and board_chess.turn == ch.WHITE) or
                                            (peca_clicada.time == "pretas" and board_chess.turn == ch.BLACK)
                                        )
                                        if turno_correto:
                                            casa_origem_ch = casa_atual_ch
                                            linha_origem = linha_p
                                            coluna_origem = coluna_p
                                            peca_clicada.selecionado = True
                                            j.selecionado = True
                                            for movimento in board_chess.legal_moves:
                                                if movimento.from_square == casa_origem_ch:
                                                    linha_destino = 7 - ch.square_rank(movimento.to_square)
                                                    coluna_destino = ch.square_file(movimento.to_square)
                                                    tabuleiro[linha_destino][coluna_destino].possivel = True
                                else:
                                    movimento = ch.Move(casa_origem_ch, casa_atual_ch)
                                    movimento_promo = ch.Move(casa_origem_ch, casa_atual_ch, promotion=ch.QUEEN)

                                    game_Xad[linha_origem][coluna_origem].selecionado = False
                                    mov_exec = None
                                    if movimento in board_chess.legal_moves:
                                        mov_exec = movimento
                                    elif movimento_promo in board_chess.legal_moves:
                                        mov_exec = movimento_promo

                                    if mov_exec:
                                        board_chess.push(mov_exec)
                                        sincronizar_xadrez(mov_exec)
                                    if contra_ia and board_chess.turn == ch.BLACK and not board_chess.is_game_over():
                                        _, movimento_computador = minimax(board_chess, 2, False)

                                        if movimento_computador is not None:
                                            board_chess.push(movimento_computador)
                                            sincronizar_xadrez(movimento_computador)

                                    for linha_t in tabuleiro:
                                        for casa_t in linha_t:
                                            casa_t.selecionado = False
                                            casa_t.possivel = False

                                    casa_origem_ch = None
                                    linha_origem = None
                                    coluna_origem = None

        for i in game_Xad:
            for j in i:
                if j != "-":
                    j.auto_locate(game_Xad)
        TELA.fill((255, 197, 0))
        for i in tabuleiro:
            for j in i:
                j.aparecer()
        all_quadros3.update()
        all_quadros3.draw(TELA)
        TELA.fill((255, 197, 0))
        for i in tabuleiro:
            for j in i:
                j.aparecer()
        all_quadros3.update()
        all_quadros3.draw(TELA)

        tempo_b = relat["atual_xad"]["tempo_b"]
        tempo_p = relat["atual_xad"]["tempo_p"]
        txt_b = font.render(f"B: {int(tempo_b)//60}:{int(tempo_b)%60:02d}", True, (0, 0, 0))
        txt_p = font.render(f"P: {int(tempo_p)//60}:{int(tempo_p)%60:02d}", True, (0, 0, 0))
        TELA.blit(txt_p, (305, 40))
        TELA.blit(txt_b, (305, 520))
        TELA.blit(font.render("ESC: voltar ao menu", True, (0, 0, 0)), [5, 5])
        status_ia = "ligada" if contra_ia else "desligada"
        TELA.blit(font.render(f"IA: {status_ia}", True, (0, 0, 0)), [5, 40])
        gam.display.flip()

        if board_chess.is_game_over():
            jogando_xa = False

    if board_chess.is_game_over():
        if board_chess.is_checkmate():
            vencedor = "Pretas" if board_chess.turn == ch.WHITE else "Brancas"
            resultado = f"Vencedor: {vencedor}"
        else:
            resultado = "Resultado: Empate"

        relat["ultimo5"] = relat["ultimo4"].copy()
        relat["ultimo4"] = relat["ultimo3"].copy()
        relat["ultimo3"] = relat["ultimo2"].copy()
        relat["ultimo2"] = relat["ultimo1"].copy()
        pontuacao_pretas = 39 - sum(
            VALORES_XADREZ[peca.piece_type]
            for peca in board_chess.piece_map().values()
            if peca.color == ch.WHITE and peca.piece_type != ch.KING
        )

        pontuacao_brancas = 39 - sum(
            VALORES_XADREZ[peca.piece_type]
            for peca in board_chess.piece_map().values()
            if peca.color == ch.BLACK and peca.piece_type != ch.KING
        )
        relat["ultimo1"] = {

            "game": "Jogo: Xadrez",
            "vencedor": resultado.replace("Resultado: ", "Vencedor: "),
            "pontuacao_B": f"Pontuação Brancas: {pontuacao_brancas}",
            "pontuacao_P": f"Pontuação Pretas: {pontuacao_pretas}",
            "tempo": f"Tempo de jogo: {int(relat['atual_xad']['tempo_b'] + relat['atual_xad']['tempo_p'])//60}:{int(relat['atual_xad']['tempo_b'] + relat['atual_xad']['tempo_p'])%60:02d}"
        }

        resetar_xadrez()

        with open("historico_jogos.json", "w") as arquivo:
            J.dump(relat, arquivo, indent=4)

        jogando_xa = False
        historico1 = True
        v_historico = True

    while not(saida) and v_historico:
            dt = clock.tick(30)
    
            pos_mouse = gam.mouse.get_pos()
    
            for evento in gam.event.get():
                if evento.type == gam.QUIT or saida:
                    saida=True
                    break
                if evento.type == gam.MOUSEBUTTONDOWN:
                    if evento.button == 1:
                        if fechar_b.rect.collidepoint(pos_mouse):
                            v_historico = False
                        elif historico1_b.rect.collidepoint(pos_mouse):
                            historico1 = True
                        elif historico2_b.rect.collidepoint(pos_mouse):
                            historico2 = True
                        elif historico3_b.rect.collidepoint(pos_mouse):
                            historico3 = True
                        elif historico4_b.rect.collidepoint(pos_mouse):
                            historico4 = True
                        elif historico5_b.rect.collidepoint(pos_mouse):
                            historico5 = True
                        
    
    
            TELA.fill((0, 162, 232))
            fechar_b.A(fechar_b.rect.collidepoint(pos_mouse))
            if len(relat["ultimo2"]) > 0:
                historico2_b.move(290,100)
                if not(historico2_b.rect.collidepoint(pos_mouse)):
                    TELA.blit(font.render('Historico 2', True, (0,0,0)), [285,200])
                else:
                    TELA.blit(font.render('Historico 2', True, (0,110,0)), [285,200])
            if len(relat["ultimo3"]) > 0:
                historico3_b.move(470,100)
                if not(historico3_b.rect.collidepoint(pos_mouse)):
                    TELA.blit(font.render('Historico 3', True, (0,0,0)), [465,200])
                else:
                    TELA.blit(font.render('Historico 3', True, (0,110,0)), [465,200])
            if len(relat["ultimo4"]) > 0:
                historico4_b.move(195,300)
                if not(historico4_b.rect.collidepoint(pos_mouse)):
                    TELA.blit(font.render('Historico 4', True, (0,0,0)), [190,400])
                else:
                    TELA.blit(font.render('Historico 4', True, (0,110,0)), [190,400])
            if len(relat["ultimo5"]) > 0:
                historico5_b.move(375,300)
                if not(historico5_b.rect.collidepoint(pos_mouse)):
                    TELA.blit(font.render('Historico 5', True, (0,0,0)), [370,400])
                else:
                    TELA.blit(font.render('Historico 5', True, (0,110,0)), [370,400])
    
            if not(historico1_b.rect.collidepoint(pos_mouse)):
                TELA.blit(font.render('Historico 1', True, (0,0,0)), [105,200])
            else:
                TELA.blit(font.render('Historico 1', True, (0,110,0)), [105,200])
    
            all_quadros4.draw(TELA)
            gam.display.flip()
    
            while not(saida) and historico1:
                dt = clock.tick(30)
                            
                pos_mouse = gam.mouse.get_pos()
            
                for evento in gam.event.get():
                    if evento.type == gam.QUIT or saida:
                        saida=True
                        break
                    if evento.type == gam.MOUSEBUTTONDOWN:
                        if evento.button == 1:
                            historico1 = False
    
    
    
                TELA.fill((0, 162, 232))
                for i, v in enumerate(relat["ultimo1"].values()):
                    texto = font.render(v,True,(255,255,255))
                    TELA.blit(texto, [200, 80 + 40 * i])
    
                gam.display.flip()
    
            while not(saida) and historico2:
                dt = clock.tick(30)
                            
                pos_mouse = gam.mouse.get_pos()
            
                for evento in gam.event.get():
                    if evento.type == gam.QUIT or saida:
                        saida=True
                        break
                    if evento.type == gam.MOUSEBUTTONDOWN:
                        if evento.button == 1:
                            historico2 = False
    
    
    
                TELA.fill((0, 162, 232))
                for i, v in enumerate(relat["ultimo2"].values()):
                    texto = font.render(v,True,(255,255,255))
                    TELA.blit(texto, [200, 80 + 40 * i])
    
                gam.display.flip()
    
            while not(saida) and historico3:
                dt = clock.tick(30)
                            
                pos_mouse = gam.mouse.get_pos()
            
                for evento in gam.event.get():
                    if evento.type == gam.QUIT or saida:
                        saida=True
                        break
                    if evento.type == gam.MOUSEBUTTONDOWN:
                        if evento.button == 1:
                            historico3 = False
    
    
    
                TELA.fill((0, 162, 232))
                for i, v in enumerate(relat["ultimo3"].values()):
                    texto = font.render(v,True,(255,255,255))
                    TELA.blit(texto, [200, 80 + 40 * i])
    
                gam.display.flip()
    
            while not(saida) and historico4:
                dt = clock.tick(30)
                            
                pos_mouse = gam.mouse.get_pos()
            
                for evento in gam.event.get():
                    if evento.type == gam.QUIT or saida:
                        saida=True
                        break
                    if evento.type == gam.MOUSEBUTTONDOWN:
                        if evento.button == 1:
                            historico4 = False
    
    
    
                TELA.fill((0, 162, 232))
                for i, v in enumerate(relat["ultimo4"].values()):
                    texto = font.render(v,True,(255,255,255))
                    TELA.blit(texto, [200, 80 + 40 * i])
    
                gam.display.flip()
    
            while not(saida) and historico5:
                dt = clock.tick(30)
                            
                pos_mouse = gam.mouse.get_pos()
            
                for evento in gam.event.get():
                    if evento.type == gam.QUIT or saida:
                        saida=True
                        break
                    if evento.type == gam.MOUSEBUTTONDOWN:
                        if evento.button == 1:
                            historico5 = False
    
    
    
                TELA.fill((0, 162, 232))
                for i, v in enumerate(relat["ultimo5"].values()):
                    texto = font.render(v,True,(255,255,255))
                    TELA.blit(texto, [200, 80 + 40 * i])
    
                gam.display.flip()
    
