// using System.Reflection.PortableExecutable;
using System.Diagnostics;
class Program
{
    static string Titulo = "Fast Labinto";
    static string[,] facil =
    {
        {"#","█","#","#","#","#","#","#","#","#","#","#","#","#"},
        {"#"," ","#","#","#"," "," "," "," ","#"," "," ","#","#"},
        {"#"," "," ","#","#"," ","#","#"," ","#"," ","#","#","#"},
        {"#","#"," ","#","#"," "," ","#"," ","#"," ","#","#","#"},
        {"#","#"," ","#","#","#"," ","#"," "," "," ","#","#","#"},
        {"#","#"," "," "," ","#"," ","#","#","#"," "," "," ","#"},
        {"#","#"," ","#"," "," "," ","#","#","#"," ","#","#","#"},
        {"#"," "," ","#"," ","#","#","#","#","#"," ","#","#","#"},
        {"#"," ","#","#"," ","#","#","#","#","#"," "," "," ","#"},
        {"#"," ","#","#"," ","#","#","#","#","#","#","#"," ","#"},
        {"#","☺","#","#"," "," ","#","#","#","#","#","#"," ","#"},
        {"#","#","#","#","#"," "," "," "," "," ","○","#","¥","#"},
        {"#","#","#","#","#","#","#","#","#","#","#","#","#","#"}
    };
    static string[,] medio =
    {
        {"#","#","#","█","#","#","#","#","#","#","#","#","#","#","#","#","#"},
        {"#","#"," "," ","#","▼","#","#","#","#"," ","○","#"," "," "," ","#"},
        {"#","#"," ","#","#"," ","#","#","#","#"," ","#","#"," ","#","¥","#"},
        {"#"," "," ","#","#"," ","○","#"," "," "," ","#","#"," ","#","#","#"},
        {"#"," ","#","#","#"," ","#","#","#","#"," "," ","#"," "," "," ","#"},
        {"#"," "," "," ","#"," ","#","#","#","#","#"," ","#","#","#"," ","#"},
        {"#","#","#"," ","#"," "," "," "," ","#","#"," "," ","#","#"," ","#"},
        {"#","☺","#"," "," "," ","#","#"," "," ","#","#"," "," ","#"," ","#"},
        {"#"," ","#","#","#"," "," "," ","#"," ","#","#"," ","#","#"," ","#"},
        {"#"," ","#","#","#"," ","#"," ","#"," "," "," "," ","#","#"," ","#"},
        {"#"," ","#"," "," "," ","#"," ","#"," ","#","#","#","#","#"," ","#"},
        {"#"," ","#"," ","#"," "," "," ","#"," ","#","#","#","#","#"," ","#"},
        {"#"," "," "," ","#"," ","#","#","#"," ","#"," "," "," ","#"," ","#"},
        {"#","#","#","#","#"," ","#","#","#"," ","#"," ","#"," ","#"," ","#"},
        {"#","#","#","#","○"," ","#","#","#"," "," "," ","#"," "," "," ","#"},
        {"#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#","#"}
    };
    static int x, y, vida = 3;
    static string[] dados=[];
    static int maxF = 0, maxM = 0;
    
    
    static void Main()
    {
        if (File.Exists("save.txt"))
        {
            dados = File.ReadAllLines("save.txt");
            maxF = int.Parse(dados[0]);
            maxM = int.Parse(dados[1]);
        }

        int proximoX;
        int proximoY;
        string blocoAlvo;

        Stopwatch crom = new Stopwatch();
        crom.Start();
        crom.Stop();
        TimeSpan T;
        int score, coin;

        var jogando = true;
        bool victory = false;
        bool[] haskey, coins_pegas;
        List<List<int>> coins;
        int mortes = 0;
        
        string[,] lab1, lab2, lab3;
        Console.Title = Titulo;
        Console.CursorVisible = false;
        while (jogando)
        {
            Console.Clear();
            Console.WriteLine("Press Esc para sair");
            Console.WriteLine("Escolha a dificuldade");
            Console.WriteLine("press: A: Fácil | B: Médio | C: Melhores Scores");
            ConsoleKeyInfo acao = Console.ReadKey(true);
            if(acao.Key == ConsoleKey.A)
            {
                Console.Clear();

                x = 1;
                y = 10;
                vida = 3;
                score = 3000;
                coin = 0;

                haskey = [false];
                coins_pegas = [false];
                coins = AcharCoins(facil);
                
                lab1 = (string[,])facil.Clone();
                // lab1[y, x] = "☺"; 
                lab2 = (string[,])lab1.Clone();
                lab3 = (string[,])lab1.Clone();
                crom.Restart();
                while (true)
                {
                    if (vida == 0)
                    {
                        vida = 3;
                        mortes++;
                        if (!haskey[0])
                        {
                            x = 1; y = 10;
                            lab1 = (string[,])facil.Clone();
                            if (coins_pegas[0]) lab1[coins[0][1],coins[0][0]] = " ";
                            lab1[y, x] = "☺";
                            lab2 = (string[,])lab1.Clone();
                            
                        }
                        else
                        {
                            x = 12; y = 11;
                            lab1 = (string[,])facil.Clone();
                            if (coins_pegas[0]) lab1[coins[0][1],coins[0][0]] = " ";
                            lab1[y, x] = "☺";
                            lab1[10, 1] = " ";
                            lab1[0,1] = "░";
                            lab2 = (string[,])lab1.Clone();
                           
                        }
                        
                    }
                    
                    if (coins_pegas[0]) lab1[coins[0][1],coins[0][0]] = " ";

                    lab3 = (string[,])lab2.Clone();
                    lab2 = (string[,])lab1.Clone();

                    lab1[y, x] = "☺";
                    
                    Console.Clear();
                    Console.WriteLine("Press Esc para sair");
                    Console.WriteLine($"Vida: {vida} | coins {coin} │ Mortes: {mortes} | Tempo: {crom.Elapsed.Minutes}:{crom.Elapsed.Seconds}\n");
                    
                    for (int i = 0; i < lab1.GetLength(0); i++) 
                    {
                        for (int j = 0; j < lab1.GetLength(1); j++) 
                        {
                            Console.Write($"{lab1[i, j]} ");
                        }
                        Console.WriteLine(); 
                    }
                    
                    Console.WriteLine("\nA: ← │ W: ↑ │ S: ↓ │ D: →");
                    acao = Console.ReadKey(true);
                    proximoX = x;
                    proximoY = y;

                    if (acao.Key == ConsoleKey.A) proximoX--;
                    else if (acao.Key == ConsoleKey.D) proximoX++;
                    else if (acao.Key == ConsoleKey.W) proximoY--;
                    else if (acao.Key == ConsoleKey.S) proximoY++;
                    else if (acao.Key == ConsoleKey.Escape) 
                    {
                        victory=false;
                        break;
                    }
                    else continue;
                    blocoAlvo = lab1[proximoY, proximoX];

                    if (blocoAlvo == "░")
                    {
                        victory = true;
                        break;
                    }
                    else if (blocoAlvo == "#" || blocoAlvo == "█")
                    {
                        vida--;
                        lab1 = (string[,])lab3.Clone();
                        lab2 = (string[,])lab3.Clone();
                        SincronizarCoordenadas(lab1);
                    }
                    else 
                    {
                        lab1[y, x] = " ";   
                        x = proximoX;       
                        y = proximoY;
                        lab1[y, x] = "☺";
                        if (blocoAlvo == "¥")
                        {
                            haskey[0] = true;
                            lab1[0,1] = "░";
                        }
                        if (blocoAlvo == "○")
                        {
                            coin++;
                            if(proximoX == coins[0][0] && proximoY == coins[0][1]) coins_pegas[0] =true;
                        }
                    }
                }
                
                crom.Stop();
                T = crom.Elapsed;

                if (victory)
                {
                    if (maxF > score + vida*30 +coin*150 - mortes*100 - (T.Seconds + T.Minutes * 60) * 20)
                    {
                        while (true)
                        {
                            Console.Clear();
                            
                            Console.WriteLine($"vida  |  {vida}");
                            Console.WriteLine($"coins |  {coin}");
                            Console.WriteLine($"mortes|  {mortes}");
                            Console.WriteLine($"tempo |  {T.Minutes}:{T.Seconds}");
                            Console.WriteLine("______________________");
                            Console.WriteLine($"score |  {score + vida*30 +coin*150 - mortes*100 - (T.Seconds + T.Minutes*60)*20}");
                            Console.WriteLine($"\nBest Score: {maxF}");
                            Console.WriteLine("\nPress Esc para sair");
                            acao = Console.ReadKey(true);
                            if (acao.Key == ConsoleKey.Escape) 
                            {
                                victory=false;
                                break;
                            }
                        }
                    }
                    else
                    {
                        maxF= score + vida*30 +coin*150 - mortes*100 - (T.Seconds + T.Minutes*60)*20;
                        dados = [maxF.ToString(), maxM.ToString()];
                        File.WriteAllLines("save.txt", dados);
                        while (true)
                        {
                            Console.Clear();
                            
                            Console.WriteLine($"vida  |  {vida}");
                            Console.WriteLine($"coins |  {coin}");
                            Console.WriteLine($"mortes|  {mortes}");
                            Console.WriteLine($"tempo |  {T.Minutes}:{T.Seconds}");
                            Console.WriteLine("______________________");
                            Console.WriteLine($"score |  {score + vida*30 +coin*150 - mortes*100 - (T.Seconds + T.Minutes*60)*20}");
                            Console.WriteLine("\nNew Record!");
                            Console.WriteLine("\nPress Esc para sair");
                            acao = Console.ReadKey(true);
                            if (acao.Key == ConsoleKey.Escape) 
                            {
                                victory=false;
                                break;
                            }
                        }
                    }
                }
            }          
            else if(acao.Key == ConsoleKey.B)
            {
                Console.Clear();

                
                vida = 3;
                score = 3000;
                coin = 0;

                haskey = [false];
                coins_pegas = [false,false,false];
                coins = AcharCoins(medio);
                bool tiro = true;
                int c=2;
                SincronizarCoordenadas(medio);
                
                lab1 = (string[,])medio.Clone();
                // lab1[y, x] = "☺"; 
                lab2 = (string[,])medio.Clone();
                lab3 = (string[,])medio.Clone();
                crom.Restart();
                while (true)
                {
                    if (vida == 0)
                    {
                        vida = 3;
                        mortes++;
                        if (!haskey[0])
                        {
                            
                            lab1 = (string[,])medio.Clone();
                            SincronizarCoordenadas(lab1);
                            if (coins_pegas[0]) lab1[coins[0][1],coins[0][0]] = " ";
                            if (coins_pegas[1]) lab1[coins[1][1],coins[1][0]] = " ";
                            if (coins_pegas[2]) lab1[coins[2][1],coins[2][0]] = " ";
                            lab1[y, x] = "☺";
                            lab2 = (string[,])lab1.Clone();
                            
                        }
                        else
                        {
                            
                            lab1 = (string[,])medio.Clone();
                            SincronizarCoordenadas(lab1);
                            lab1[y, x] = " ";
                            x = 15; y = 2;
                            if (coins_pegas[0]) lab1[coins[0][1],coins[0][0]] = " ";
                            if (coins_pegas[1]) lab1[coins[1][1],coins[1][0]] = " ";
                            if (coins_pegas[2]) lab1[coins[2][1],coins[2][0]] = " ";
                            lab1[y, x] = "☺";
                            
                            lab1[0,3] = "░";
                            lab2 = (string[,])lab1.Clone();
                           
                        }
                        
                    }
                    
                    if (coins_pegas[0]) lab1[coins[0][1],coins[0][0]] = " ";
                    if (coins_pegas[1]) lab1[coins[1][1],coins[1][0]] = " ";
                    if (coins_pegas[2]) lab1[coins[2][1],coins[2][0]] = " ";

                    lab3 = (string[,])lab2.Clone();
                    lab2 = (string[,])lab1.Clone();

                    if (c > 2 && lab2[c - 1, 5] == "¤") lab2[c - 1, 5] = " ";
                    if (c > 2 && lab3[c - 1, 5] == "¤") lab3[c - 1, 5] = " ";

                    lab1[y, x] = "☺";

                    Console.Clear();
                    Console.WriteLine("Press Esc para sair");
                    Console.WriteLine($"Vida: {vida} | coins {coin} │ Mortes: {mortes} | Tempo: {crom.Elapsed.Minutes}:{crom.Elapsed.Seconds}\n");
                    
                    for (int i = 0; i < lab1.GetLength(0); i++) 
                    {
                        for (int j = 0; j < lab1.GetLength(1); j++) 
                        {
                            Console.Write($"{lab1[i, j]} ");
                        }
                        Console.WriteLine(); 
                    }
                    
                    Console.WriteLine("\nA: ← │ W: ↑ │ S: ↓ │ D: →");
                    acao = Console.ReadKey(true);
                    proximoX = x;
                    proximoY = y;

                    if (acao.Key == ConsoleKey.A) proximoX--;
                    else if (acao.Key == ConsoleKey.D) proximoX++;
                    else if (acao.Key == ConsoleKey.W) proximoY--;
                    else if (acao.Key == ConsoleKey.S) proximoY++;
                    else if (acao.Key == ConsoleKey.Escape) 
                    {
                        victory=false;
                        break;
                    }
                    else continue;
                    blocoAlvo = lab1[proximoY, proximoX];

                    if (blocoAlvo == "░")
                    {
                        victory = true;
                        break;
                    }
                    else if (blocoAlvo == "#" || blocoAlvo == "█" || blocoAlvo == "¤" || blocoAlvo == "▼")
                    {
                        vida--;
                        lab1 = (string[,])lab3.Clone();
                        lab2 = (string[,])lab3.Clone();
                        SincronizarCoordenadas(lab1);
                        if (blocoAlvo == "¤")
                        {
                            tiro=false;
                            lab1[proximoY, proximoX]=" ";
                            c=2;
                        }
                    }
                    else 
                    {
                        lab1[y, x] = " ";   
                        x = proximoX;       
                        y = proximoY;
                        lab1[y, x] = "☺";
                        if (blocoAlvo == "¥")
                        {
                            haskey[0] = true;
                            lab1[0,3] = "░";
                        }
                        if (blocoAlvo == "○")
                        {
                            coin++;
                            if(proximoX == coins[0][0] && proximoY == coins[0][1]) coins_pegas[0] =true;
                            if(proximoX == coins[1][0] && proximoY == coins[1][1]) coins_pegas[1] =true;
                            if(proximoX == coins[2][0] && proximoY == coins[2][1]) coins_pegas[2] =true;
                        }
                        if (tiro)
                        {
                            if (c > 2 && lab1[c - 1, 5] == "¤") lab1[c - 1, 5] = " ";
                            if (lab1[c, 5] == "☺")
                            {
                                vida--;
                                tiro = false;
                                c = 2;
                                
                                lab1 = (string[,])lab3.Clone();
                                lab2 = (string[,])lab3.Clone();
                                SincronizarCoordenadas(lab1);
                            }
                            else if (lab1[c, 5] == "#" || lab1[c, 5] == "█" || lab1[c, 5] == "▼")
                            {
                                tiro = false;
                                c = 2;
                            }
                            else
                            {
                                lab1[c,5]="¤";
                                c++;
                            }
                           
                        }
                        else
                        {
                            tiro=true;
                            c=2;
                        }
                        
                    }
                }
                
                crom.Stop();
                T = crom.Elapsed;

                if (victory)
                {
                    if (maxM > score + vida*30 +coin*150 - mortes*100 - (T.Seconds + T.Minutes * 60) * 20)
                    {
                        while (true)
                        {
                            Console.Clear();
                            
                            Console.WriteLine($"vida  |  {vida}");
                            Console.WriteLine($"coins |  {coin}");
                            Console.WriteLine($"mortes|  {mortes}");
                            Console.WriteLine($"tempo |  {T.Minutes}:{T.Seconds}");
                            Console.WriteLine("______________________");
                            Console.WriteLine($"score |  {score + vida*30 +coin*150 - mortes*100 - (T.Seconds + T.Minutes*60)*20}");
                            Console.WriteLine($"\nBest Score: {maxM}");
                            Console.WriteLine("\nPress Esc para sair");
                            acao = Console.ReadKey(true);
                            if (acao.Key == ConsoleKey.Escape) 
                            {
                                victory=false;
                                break;
                            }
                        }
                    }
                    else
                    {
                        maxM= score + vida*30 +coin*150 - mortes*100 - (T.Seconds + T.Minutes*60)*20;
                        dados = [maxF.ToString(), maxM.ToString()];
                        File.WriteAllLines("save.txt", dados);
                        while (true)
                        {
                            Console.Clear();
                            
                            Console.WriteLine($"vida  |  {vida}");
                            Console.WriteLine($"coins |  {coin}");
                            Console.WriteLine($"mortes|  {mortes}");
                            Console.WriteLine($"tempo |  {T.Minutes}:{T.Seconds}");
                            Console.WriteLine("______________________");
                            Console.WriteLine($"score |  {score + vida*30 +coin*150 - mortes*100 - (T.Seconds + T.Minutes*60)*20}");
                            Console.WriteLine("\nNew Record!");
                            Console.WriteLine("\nPress Esc para sair");
                            acao = Console.ReadKey(true);
                            if (acao.Key == ConsoleKey.Escape) 
                            {
                                victory=false;
                                break;
                            }
                        }
                    }
                }
            }
            else if(acao.Key == ConsoleKey.C)
            {
                while (true)
                {
                    Console.Clear();
                    Console.WriteLine("Melhores Scores:");
                    Console.WriteLine($"Best Score Fácil: {maxF} | Best Score Médio: {maxM}");
                    Console.WriteLine("\nPress Esc para sair");

                    acao = Console.ReadKey(true);
                    if(acao.Key == ConsoleKey.Escape) break;
                }
                

            }
            else if(acao.Key == ConsoleKey.Escape) jogando = false;
        
        Console.Clear();
        Console.WriteLine("Fim de Jogo");
        Console.CursorVisible = true;
    }

    
    static void SincronizarCoordenadas(string[,] lab)
    {
        for (int i = 0; i < lab.GetLength(0); i++)
        {
            for (int j = 0; j < lab.GetLength(1); j++)
            {
                if (lab[i, j] == "☺")
                {
                    y = i;
                    x = j;
                    return;
                }
            }
        }
    }
    static List<List<int>> AcharCoins(string[,] lab)
    {
        List<List<int>> a=[];
        List<int> b;
        for (int i = 0; i < lab.GetLength(0); i++)
        {
            for (int j = 0; j < lab.GetLength(1); j++)
            {
                if (lab[i, j] == "○")
                {
                    b = [j,i];
                    a.Add(b);
                }
            }
        }
        return a;
    }
}}